import React from 'react'
import headerMock from '../img/header-mock.png'

export const Header = () => {
  return <img src={headerMock} width="100%" />
}
