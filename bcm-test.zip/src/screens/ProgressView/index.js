import React from 'react'
import { ProgressBars } from '../../components/ProgressBars'
import { SvgLayout } from './SvgLayout'

export const ProgressView = () => {
  return (
    <div>
      <SvgLayout />
    </div>
  )
}
