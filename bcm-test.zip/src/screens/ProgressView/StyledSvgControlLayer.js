import styled from 'styled-components/macro'

export const StyledSvgControlLayer = styled.div`
  .section1,
  .section2,
  .section3,
  .section4 {
    transform: translate(0px, 0px);
    transition: all 0.6s;
    cursor: pointer;

    .outerRingWhite {
      fill-opacity: 0.5;
    }

    .innerCircleWhite {
      fill-opacity: 0.75;
    }

    .progressFill {
      fill: #dabdff;
    }

    .progressCircle {
      fill: #b57bff;
    }

    &:hover {
      .outerRingWhite {
        fill-opacity: 0;
      }

      .innerCircleWhite {
        fill-opacity: 0;
      }

      .progressFill {
        fill: rgb(157, 223, 157);
      }

      .progressCircle {
        fill: #3cc13b;
      }
    }
  }

  .section1 {
    transform: translate(32px, 32px);
  }

  .section1:hover {
    transform: translate(0px, 0px);
  }

  .section2:hover {
    transform: translate(32px, -32px);
  }

  .section3:hover {
    transform: translate(32px, 32px);
  }

  .section4:hover {
    transform: translate(-32px, 32px);
  }

  .circle_text {
    font-family: Arial, Helvetica, sans-serif;
    font-weight: bold;
    font-size: 16px;
    fill: white;
  }
`
