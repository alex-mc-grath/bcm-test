import React from 'react'

import { SvgControlLayout } from './SvgControlLayout'

export const SvgLayout = () => {
  return (
    <div>
      <SvgControlLayout />
    </div>
  )
}
